#!/usr/bin/env python
from onmt.bin.preprocess import main


if __name__ == "__main__":
    main()
