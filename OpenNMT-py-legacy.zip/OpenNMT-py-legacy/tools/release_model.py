#!/usr/bin/env python
from onmt.bin.release_model import main


if __name__ == "__main__":
    main()
