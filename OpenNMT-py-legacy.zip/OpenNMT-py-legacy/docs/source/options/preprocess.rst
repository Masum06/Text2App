Preprocess
==========

.. argparse::
    :filename: ../onmt/bin/preprocess.py
    :func: _get_parser
    :prog: preprocess.py