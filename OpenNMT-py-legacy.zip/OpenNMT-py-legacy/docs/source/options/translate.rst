Translate
=========

.. argparse::
    :filename: ../onmt/bin/translate.py
    :func: _get_parser
    :prog: translate.py