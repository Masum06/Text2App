Server
=========

.. argparse::
    :filename: ../onmt/bin/server.py
    :func: _get_parser
    :prog: server.py